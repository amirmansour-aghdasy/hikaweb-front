import { ScrollTop } from "@/components/action_buttons";

const ActionButtonsContainer = () => {
    return ( 
        <>
            <ScrollTop />
        </>
     );
}
 
export default ActionButtonsContainer;