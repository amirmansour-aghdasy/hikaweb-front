import { Goftino } from "@/components/scripts";

const ScriptsContainer = () => {
    return (
        <>
            <Goftino />
        </>
    );
};

export default ScriptsContainer;
