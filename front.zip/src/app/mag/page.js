const MagHomePage = () => {
    return ( "Hika Mag Home Page" );
}
 
export default MagHomePage;