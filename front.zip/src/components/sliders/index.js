export { default as ServiceProcessSlider } from "./ServiceProcessSlider";
export { default as ServicePricingPlansSlider } from "./ServicePricingPlansSlider";