export { default as SlidersSection } from "./SlidersSection";
export { default as ServicesSection } from "./ServicesSection";
export { default as CommentsSection } from "./CommentsSection";
export { default as PortfolioPreview } from "./PortfolioPreview";
export { default as MagPreviewSection } from "./MagPreviewSection";
export { default as BrandsSliderSection } from "./BrandsSliderSection";